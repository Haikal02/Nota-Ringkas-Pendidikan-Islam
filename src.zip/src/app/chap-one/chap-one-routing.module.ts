import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChapOnePage } from './chap-one.page';

const routes: Routes = [
  {
    path: '',
    component: ChapOnePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChapOnePageRoutingModule {}
