import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BahagianTigaPage } from './bahagian-tiga.page';

const routes: Routes = [
  {
    path: '',
    component: BahagianTigaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BahagianTigaPageRoutingModule {}
