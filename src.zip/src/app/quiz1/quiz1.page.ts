import { Component, OnInit, ViewChild } from '@angular/core';
import { AlertController, IonSlides } from '@ionic/angular';


@Component({
  selector: 'app-quiz1',
  templateUrl: './quiz1.page.html',
  styleUrls: ['./quiz1.page.scss'],
})


export class Quiz1Page {
  @ViewChild('mySlider') slides: IonSlides;

  swipeNext() {
    this.slides.slideNext();
  }

  constructor(private alertCtrl: AlertController) {}

  async correctAnswer(){
      await this.alertCtrl.create({
      header: "Congratulation!",
      subHeader:"That answer is correct.",
      // inputs: [
      //   { type: 'text', name:'promo', placeholder: "Promo code"}
      // ],
      buttons:[
      //   { text: "Next", handler: (res) => {
      //      console.log(res.promo);
      //   } 
      // },
      {
        text: "Okay"
      }
      ]
      }).then(res => res.present());
  }

// question1
  async wrongAnswer(){
    await this.alertCtrl.create({
    header: "Study this one!",
    subHeader:"Correct answer : Registers",
    message:"Explanation: Registers are small amounts of high speed memory contained within the CPU",
    
    // inputs: [
    //   { type: 'text', name:'promo', placeholder: "Promo code"}
    // ],
    buttons:[
    //   { text: "Next", handler: (res) => {
    //      console.log(res.promo);
    //   } 
    // },
    {
      text: "Okay"
    }
    ]
    }).then(res => res.present());
}

// question2
async wrongAnswer2(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : I/O",
  message:"Explanation: I/O module is connected to the computer system on one end & one or more input/output device.Thus, it controls data exchange between external device and main memory",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question3
async wrongAnswer3(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : CPU Function",
  message:"Explanation: CPU performs all type of data processing operations and it controls the operation of all parts of the computer",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question4
async wrongAnswer4(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : System Interconnection",
  message:"Explanation: A computer consist of a set of components/module which must be connected. Thus, there must be a path for connecting the modules & this path is called system interconnection",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question5
async wrongAnswer5(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : Control Unit",
  message:"Explanation: Control Unit will control the operation of computer because control unit is a component of the CPU where all data processing happens",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

//submit
// question5
async submit(){
  await this.alertCtrl.create({
  header: "Thank You!",
  subHeader:"You did a great job answering this quiz.",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

}

