import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChapThreePageRoutingModule } from './chap-three-routing.module';

import { ChapThreePage } from './chap-three.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChapThreePageRoutingModule
  ],
  declarations: [ChapThreePage]
})
export class ChapThreePageModule {}
