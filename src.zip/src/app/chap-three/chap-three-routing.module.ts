import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChapThreePage } from './chap-three.page';

const routes: Routes = [
  {
    path: '',
    component: ChapThreePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChapThreePageRoutingModule {}
