import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MenuTwoPage } from './menu-two.page';

const routes: Routes = [
  {
    path: '',
    component: MenuTwoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MenuTwoPageRoutingModule {}
