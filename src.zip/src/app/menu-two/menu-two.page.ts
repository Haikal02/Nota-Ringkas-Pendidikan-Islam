import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-two',
  templateUrl: './menu-two.page.html',
  styleUrls: ['./menu-two.page.scss'],
})
export class MenuTwoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
