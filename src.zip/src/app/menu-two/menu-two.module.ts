import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MenuTwoPageRoutingModule } from './menu-two-routing.module';

import { MenuTwoPage } from './menu-two.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MenuTwoPageRoutingModule
  ],
  declarations: [MenuTwoPage]
})
export class MenuTwoPageModule {}
