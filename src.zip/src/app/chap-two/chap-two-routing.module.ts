import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChapTwoPage } from './chap-two.page';

const routes: Routes = [
  {
    path: '',
    component: ChapTwoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChapTwoPageRoutingModule {}
