import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChapTwoPageRoutingModule } from './chap-two-routing.module';

import { ChapTwoPage } from './chap-two.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChapTwoPageRoutingModule
  ],
  declarations: [ChapTwoPage]
})
export class ChapTwoPageModule {}
