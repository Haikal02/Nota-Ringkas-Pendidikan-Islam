import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { IonSlides } from '@ionic/angular';

@Component({
  selector: 'app-bahagian-lima',
  templateUrl: './bahagian-lima.page.html',
  styleUrls: ['./bahagian-lima.page.scss'],
})
export class BahagianLimaPage implements OnInit {

  private slidesOpts = {
    initialSlide: 0,
    speed: 500,
    effect: 'flip',
    spaceBetween: 100,
    // direction: 'vertical'
    nested: true,
    // slidesPreview: 3,
  };






@ViewChild('slides' , { static: false }) slides: IonSlides;
  constructor(private router: Router) { }

  ngOnInit() {


  }

  ionSlideDidChange(event){
    console.log("ionSlideDidChange", event);
    this.slides.getActiveIndex().then(index=>{
      console.log(index)
    })
  }

  ionSlideReachEnd(event){
    console.log(event)
  }

}
