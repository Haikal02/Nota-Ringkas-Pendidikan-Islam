import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BahagianLimaPage } from './bahagian-lima.page';

const routes: Routes = [
  {
    path: '',
    component: BahagianLimaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BahagianLimaPageRoutingModule {}
