import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import {
  LoadingController,
  NavController,
  ToastController } from '@ionic/angular';
  import { User } from '../models/user.mode';
  import { Post } from '../models/post.mode';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.page.html',
  styleUrls: ['./edit-profile.page.scss'],
})
export class EditProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
