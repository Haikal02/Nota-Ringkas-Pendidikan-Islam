import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'chap-one',
    loadChildren: () => import('./chap-one/chap-one.module').then( m => m.ChapOnePageModule)
    
  },
  {
    path: 'quiz',
    loadChildren: () => import('./quiz/quiz.module').then( m => m.QuizPageModule)
  },
  {
    path: 'quiz1',
    loadChildren: () => import('./quiz1/quiz1.module').then( m => m.Quiz1PageModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./profile/profile.module').then( m => m.ProfilePageModule)
    
  },
  {
    path: 'edit-profile',
    loadChildren: () => import('./edit-profile/edit-profile.module').then( m => m.EditProfilePageModule)
  },
  {
    path: 'chap-two',
    loadChildren: () => import('./chap-two/chap-two.module').then( m => m.ChapTwoPageModule)
  },
  {
    path: 'menu',
    loadChildren: () => import('./menu/menu.module').then( m => m.MenuPageModule)
  },
  {
    path: 'menu-two',
    loadChildren: () => import('./menu-two/menu-two.module').then( m => m.MenuTwoPageModule)
  },
  {
    path: 'faq',
    loadChildren: () => import('./faq/faq.module').then( m => m.FaqPageModule)
  },
  {
    path: 'chap-three',
    loadChildren: () => import('./chap-three/chap-three.module').then( m => m.ChapThreePageModule)
  },
  {
    path: 'chap-four',
    loadChildren: () => import('./chap-four/chap-four.module').then( m => m.ChapFourPageModule)
  },
  {
    path: 'chap-five',
    loadChildren: () => import('./chap-five/chap-five.module').then( m => m.ChapFivePageModule)
  },
  {
    path: 'bahagian-satu',
    loadChildren: () => import('./bahagian-satu/bahagian-satu.module').then( m => m.BahagianSatuPageModule)
  },
  {
    path: 'bahagian-dua',
    loadChildren: () => import('./bahagian-dua/bahagian-dua.module').then( m => m.BahagianDuaPageModule)
  },
  {
    path: 'bahagian-tiga',
    loadChildren: () => import('./bahagian-tiga/bahagian-tiga.module').then( m => m.BahagianTigaPageModule)
  },
  {
    path: 'bahagian-empat',
    loadChildren: () => import('./bahagian-empat/bahagian-empat.module').then( m => m.BahagianEmpatPageModule)
  },
  {
    path: 'bahagian-lima',
    loadChildren: () => import('./bahagian-lima/bahagian-lima.module').then( m => m.BahagianLimaPageModule)
  },
  {
    path: 'q1',
    loadChildren: () => import('./q1/q1.module').then( m => m.Q1PageModule)
  },
  {
    path: 'q2',
    loadChildren: () => import('./q2/q2.module').then( m => m.Q2PageModule)
  },
  {
    path: 'q3',
    loadChildren: () => import('./q3/q3.module').then( m => m.Q3PageModule)
  },
  {
    path: 'q4',
    loadChildren: () => import('./q4/q4.module').then( m => m.Q4PageModule)
  },
  {
    path: 'q5',
    loadChildren: () => import('./q5/q5.module').then( m => m.Q5PageModule)
  },
  {
    path: 'q6',
    loadChildren: () => import('./q6/q6.module').then( m => m.Q6PageModule)
  },
  {
    path: 'q7',
    loadChildren: () => import('./q7/q7.module').then( m => m.Q7PageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
