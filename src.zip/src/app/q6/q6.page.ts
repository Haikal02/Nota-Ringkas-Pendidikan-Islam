import { Component, OnInit, ViewChild } from '@angular/core';
import { AlertController, IonSlides } from '@ionic/angular';


@Component({
  selector: 'app-q6',
  templateUrl: './q6.page.html',
  styleUrls: ['./q6.page.scss'],
})


export class Q6Page {
  @ViewChild('mySlider') slides: IonSlides;

  swipeNext() {
    this.slides.slideNext();
  }

  swipePrev() {
    this.slides.slidePrev();
  }

  constructor(private alertCtrl: AlertController) {}

  async correctAnswer(){
      await this.alertCtrl.create({
      header: "Congratulation!",
      subHeader:"That answer is correct.",
      // inputs: [
      //   { type: 'text', name:'promo', placeholder: "Promo code"}
      // ],
      buttons:[
      //   { text: "Next", handler: (res) => {
      //      console.log(res.promo);
      //   } 
      // },
      {
        text: "OK!"
      }
      ]
      }).then(res => res.present());
  }

// question1
  async wrongAnswer(){
    await this.alertCtrl.create({
    header: "Your answer is wrong!",
    
    // inputs: [
    //   { type: 'text', name:'promo', placeholder: "Promo code"}
    // ],
    buttons:[
    //   { text: "Next", handler: (res) => {
    //      console.log(res.promo);
    //   } 
    // },
    {
      text: "OK!"
    }
    ]
    }).then(res => res.present());
}

// question2
async wrongAnswer2(){
  await this.alertCtrl.create({
  header: "Your answer is wrong!",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

// question3
async wrongAnswer3(){
  await this.alertCtrl.create({
  header: "Your answer is wrong!",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

// question4
async wrongAnswer4(){
  await this.alertCtrl.create({
  header: "Your answer is wrong!",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

// question5
async wrongAnswer5(){
  await this.alertCtrl.create({
  header: "Your answer is wrong!",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

// question6
async wrongAnswer6(){
  await this.alertCtrl.create({
  header: "Your answer is wrong!",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

// question7
async wrongAnswer7(){
  await this.alertCtrl.create({
  header: "Your answer is wrong!",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

// question8
async wrongAnswer8(){
  await this.alertCtrl.create({
  header: "Your answer is wrong!",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

// question9
async wrongAnswer9(){
  await this.alertCtrl.create({
  header: "Your answer is wrong!",

  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

// question10
async wrongAnswer10(){
  await this.alertCtrl.create({
  header: "Your answer is wrong!",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

//submit
// question5
async submit(){
  await this.alertCtrl.create({
  header: "Thank You!",
  subHeader:"You did a great job answering this quiz.",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "OK!"
  }
  ]
  }).then(res => res.present());
}

}