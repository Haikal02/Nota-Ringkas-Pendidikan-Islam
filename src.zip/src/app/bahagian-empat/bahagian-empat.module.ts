import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BahagianEmpatPageRoutingModule } from './bahagian-empat-routing.module';

import { BahagianEmpatPage } from './bahagian-empat.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BahagianEmpatPageRoutingModule
  ],
  declarations: [BahagianEmpatPage]
})
export class BahagianEmpatPageModule {}
