import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BahagianEmpatPage } from './bahagian-empat.page';

const routes: Routes = [
  {
    path: '',
    component: BahagianEmpatPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BahagianEmpatPageRoutingModule {}
