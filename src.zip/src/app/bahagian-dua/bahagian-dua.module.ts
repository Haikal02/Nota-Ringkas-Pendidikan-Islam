import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BahagianDuaPageRoutingModule } from './bahagian-dua-routing.module';

import { BahagianDuaPage } from './bahagian-dua.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BahagianDuaPageRoutingModule
  ],
  declarations: [BahagianDuaPage]
})
export class BahagianDuaPageModule {}
