import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BahagianDuaPage } from './bahagian-dua.page';

const routes: Routes = [
  {
    path: '',
    component: BahagianDuaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BahagianDuaPageRoutingModule {}
