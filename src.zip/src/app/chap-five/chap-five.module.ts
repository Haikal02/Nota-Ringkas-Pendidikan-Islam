import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChapFivePageRoutingModule } from './chap-five-routing.module';

import { ChapFivePage } from './chap-five.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChapFivePageRoutingModule
  ],
  declarations: [ChapFivePage]
})
export class ChapFivePageModule {}
