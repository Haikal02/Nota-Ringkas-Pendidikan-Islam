import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChapFivePage } from './chap-five.page';

const routes: Routes = [
  {
    path: '',
    component: ChapFivePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChapFivePageRoutingModule {}
