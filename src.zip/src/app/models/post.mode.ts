export interface Post {
    name: string;
    email: string;
    level: string;
}