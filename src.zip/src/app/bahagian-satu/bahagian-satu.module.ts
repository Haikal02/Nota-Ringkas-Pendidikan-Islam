import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BahagianSatuPageRoutingModule } from './bahagian-satu-routing.module';

import { BahagianSatuPage } from './bahagian-satu.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BahagianSatuPageRoutingModule
  ],
  declarations: [BahagianSatuPage]
})
export class BahagianSatuPageModule {}
