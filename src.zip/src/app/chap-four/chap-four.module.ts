import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChapFourPageRoutingModule } from './chap-four-routing.module';

import { ChapFourPage } from './chap-four.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChapFourPageRoutingModule
  ],
  declarations: [ChapFourPage]
})
export class ChapFourPageModule {}
